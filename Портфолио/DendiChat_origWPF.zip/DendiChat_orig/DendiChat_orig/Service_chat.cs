﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DendiChat
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class Service_chat : IService_chat
    {
        List<ServerUser> users = new List<ServerUser>();
        int nextId = 1;
        public int Connect(string name)
        {
            ServerUser user = new ServerUser() { 
                ID = nextId,
                Name = name,
                operationcontext = OperationContext.Current,
            };
            nextId++;

            SendMsg($": {user.Name} Зашёл погреться!",0);
            users.Add(user);
            return user.ID;
        }

        public void Disconnect(int id)
        {
            var user = users.FirstOrDefault(i => i.ID == id);
            if (user != null)
            {
                users.Remove(user);
                SendMsg($": {user.Name} Поссал и ушёл -_- !", 0);
            }
        }

        public void DoWork()
        {
        }

        public void SendMsg(string message, int id)
        {
            foreach (var item in users) { 
                string answer = DateTime.Now.ToShortTimeString();
                var user = users.FirstOrDefault(i => i.ID == id);
                if (user != null)
                {
                    answer += $" : <{user.Name}> ";
                }
                answer += message;

                item.operationcontext.GetCallbackChannel<IServerChatCallback>().MsgCallback(answer);

            }
        }
    }
}
