﻿using System.ServiceModel;

namespace DendiChat
{
    public class ServerUser
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public OperationContext operationcontext { get; set; }
    }
}
