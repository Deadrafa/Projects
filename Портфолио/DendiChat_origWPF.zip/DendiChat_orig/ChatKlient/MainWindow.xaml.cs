﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ChatKlient.Service_chat;

namespace ChatKlient
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IService_chatCallback
    {
        bool isConnected = false;
        Service_chatClient client;
        int ID;
        public MainWindow()
        {
            InitializeComponent();
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        void ConnectUser()
        {
            if (!isConnected)
            {

                client = new Service_chatClient(new System.ServiceModel.InstanceContext(this));
                ID = client.Connect(textbox_UserName.Text);
                textbox_UserName.IsEnabled = false;
                ButConDiscon.Content = "Disconnect";
                isConnected = true;

            }
        }

        void DisconnectUser()
        {
            if (isConnected)
            {

                client.Disconnect(ID);
                client = null;
                textbox_UserName.IsEnabled = true;
                ButConDiscon.Content = "Connect";
                isConnected = false;

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (isConnected)
            {
                DisconnectUser();
            }
            else
            {
                ConnectUser();
            }
        }

        public void MsgCallback(string message)
        {
            listbox_Chat.Items.Add(message);
            listbox_Chat.ScrollIntoView(listbox_Chat.Items[listbox_Chat.Items.Count - 1]);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            DisconnectUser();
        }

        private void textbox_Message_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (client != null)
                {
                    client.SendMsg(textboxMessage.Text, ID);
                    textboxMessage.Text = string.Empty;
                }
            }
        }

        private void listbox_Chat_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void textboxMessage_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
