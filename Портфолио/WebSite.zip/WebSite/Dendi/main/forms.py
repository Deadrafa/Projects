from .models import Users
from django.forms import ModelForm, TextInput, PasswordInput

class Users_form(ModelForm):
    class Meta:
        model = Users
        fields = ['title','anons']

        widgets = {
            "title": TextInput(attrs={
                'class': 'product__add',
                'placeholder': 'Введите логин'
            }),
            "anons": PasswordInput(attrs={
                'class': 'product__add',
                'placeholder': 'Введите пароль'
                })  
        }