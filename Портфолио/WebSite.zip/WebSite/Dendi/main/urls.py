from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    path('ebayt', views.ebayt),
    path('home', views.home),
    path('create', views.create),

]