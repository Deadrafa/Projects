from django.shortcuts import render, redirect
from .models import Users
from .forms import Users_form   
# Create your views here.

def index(request):
    print("Работает")
    return render(request, 'index.html')

def ebayt(request):
    news = Users.objects.all()
    return render(request, 'ebayt.html', {'news': news})

def home(request):
    return render(request, 'index.html')

def create(request):
    error = ''
    if request.method == 'POST':
        form = Users_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/home')

        else:
            error = 'Неправильный ввод данных'
    form = Users_form()
    data = {
        'form': form,
        'error': error 
    }
    return render(request, 'create.html', data)

