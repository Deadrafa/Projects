from django.db import models

# Create your models here.


class Users(models.Model):
    title = models.CharField('Логин', max_length=50)
    anons = models.CharField('Пароль', max_length=200)
    #full_text = models.TextChoices('Статья')
    # date = models.DateTimeField('Дата публикации')

    def __str__(self):
        return self.title
    
    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'